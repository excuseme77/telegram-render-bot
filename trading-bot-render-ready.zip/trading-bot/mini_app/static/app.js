/**
 * Trading Bot Mini App - Frontend Logic
 * Handles WebSocket, Charts, UI, API calls, Toasts
 */

// ========================================
// State
// ========================================
let ws = null;
let equityChart = null;
let currentUserId = 7318737159; // Default admin, will be updated from Telegram WebApp
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;
const RECONNECT_DELAY = 3000;

// Chart data storage
let equityData = { labels: [], values: [] };

// ========================================
// DOM Ready
// ========================================
document.addEventListener('DOMContentLoaded', () => {
    initApp();
});

async function initApp() {
    // Get user_id from Telegram WebApp initData if available
    if (window.Telegram && Telegram.WebApp) {
        Telegram.WebApp.ready();
        Telegram.WebApp.expand();
        if (Telegram.WebApp.initDataUnsafe?.user) {
            currentUserId = Telegram.WebApp.initDataUnsafe.user.id;
            console.log('User ID from Telegram WebApp:', currentUserId);
        }
    } else {
        // Fallback for testing outside Telegram
        const urlParams = new URLSearchParams(window.location.search);
        currentUserId = parseInt(urlParams.get('user_id')) || 7318737159;
    }

    console.log('Initializing app for user:', currentUserId);

    // Initialize components
    initWebSocket();
    initChart();
    initTabs();
    initModals();
    loadInitialData();

    // Periodic data refresh
    setInterval(loadDashboardData, 30000); // Every 30 seconds
}

// ========================================
// WebSocket
// ========================================
function initWebSocket() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws/${currentUserId}`;

    ws = new WebSocket(wsUrl);

    ws.onopen = () => {
        console.log('WebSocket connected');
        reconnectAttempts = 0;
        updateConnectionStatus(true);
    };

    ws.onmessage = (event) => {
        try {
            const data = JSON.parse(event.data);
            handleWebSocketMessage(data);
        } catch (e) {
            console.error('WS message parse error:', e);
        }
    };

    ws.onclose = () => {
        console.log('WebSocket disconnected');
        updateConnectionStatus(false);
        attemptReconnect();
    };

    ws.onerror = (error) => {
        console.error('WebSocket error:', error);
    };
}

function attemptReconnect() {
    if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
        reconnectAttempts++;
        console.log(`Reconnecting... attempt ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS}`);
        setTimeout(initWebSocket, RECONNECT_DELAY);
    } else {
        showToast('Connection lost. Please refresh the page.', 'error');
    }
}

function updateConnectionStatus(connected) {
    const statusEl = document.getElementById('connectionStatus');
    if (statusEl) {
        const dot = statusEl.querySelector('.dot');
        const text = statusEl.querySelector('span:last-child');
        if (connected) {
            dot.style.background = '#22c55e';
            text.textContent = 'Подключено';
        } else {
            dot.style.background = '#ef4444';
            text.textContent = 'Переподключение...';
        }
    }
}

function handleWebSocketMessage(data) {
    switch (data.type) {
        case 'init':
            updateDashboard(data);
            break;
        case 'trade_open':
            showToast(`🟢 New ${data.data.side === 'buy' ? 'LONG' : 'SHORT'} ${data.data.symbol}`, 'success');
            loadDashboardData();
            break;
        case 'trade_close':
            const isProfit = data.data.pnl > 0;
            showToast(`${isProfit ? '🟢' : '🔴'} ${data.data.symbol} closed: ${data.data.pnl >= 0 ? '+' : ''}${data.data.pnl.toFixed(4)} USDT (${data.data.pct.toFixed(2)}%)`, isProfit ? 'success' : 'error');
            loadDashboardData();
            break;
        case 'subscription_activated':
            showToast('✅ Subscription activated!', 'success');
            loadDashboardData();
            break;
        case 'position_update':
            updatePositionsList(data.positions);
            break;
        case 'equity_update':
            addEquityPoint(data.ts, data.equity);
            break;
    }
}

// ========================================
// Chart.js - Equity Curve
// ========================================
function initChart() {
    const ctx = document.getElementById('equityChart');
    if (!ctx) return;

    equityChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Equity (USDT)',
                data: [],
                borderColor: '#22d3ee',
                backgroundColor: 'rgba(34, 211, 238, 0.1)',
                borderWidth: 2,
                pointRadius: 0,
                pointHoverRadius: 6,
                tension: 0.3,
                fill: true,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#151e2e',
                    titleColor: '#f1f5f9',
                    bodyColor: '#94a3b8',
                    borderColor: '#1e293b',
                    borderWidth: 1,
                    padding: 12,
                    displayColors: false,
                    callbacks: {
                        label: (ctx) => `Equity: ${ctx.parsed.y.toFixed(2)} USDT`
                    }
                }
            },
            scales: {
                x: {
                    type: 'time',
                    time: { unit: 'hour', tooltipFormat: 'HH:mm DD.MM' },
                    grid: { color: 'rgba(30, 41, 59, 0.5)' },
                    ticks: { color: '#64748b', font: { size: 10 } }
                },
                y: {
                    grid: { color: 'rgba(30, 41, 59, 0.3)' },
                    ticks: {
                        color: '#64748b',
                        font: { size: 10 },
                        callback: (v) => v.toFixed(2) + ' USDT'
                    }
                }
            },
            animation: { duration: 300 }
        }
    });
}

function addEquityPoint(timestamp, equity) {
    if (!equityChart) return;
    const date = new Date(timestamp * 1000);
    equityChart.data.labels.push(date);
    equityChart.data.datasets[0].data.push(equity);

    // Keep last 200 points
    if (equityChart.data.labels.length > 200) {
        equityChart.data.labels.shift();
        equityChart.data.datasets[0].data.shift();
    }
    equityChart.update('none');
}

function setEquityData(history) {
    if (!equityChart || !history?.length) return;
    equityChart.data.labels = history.map(h => new Date(h.ts * 1000));
    equityChart.data.datasets[0].data = history.map(h => h.equity);
    equityChart.update();
}

// ========================================
// Dashboard Data
// ========================================
async function loadDashboardData() {
    try {
        const [status, subscription] = await Promise.all([
            fetch(`/api/status?user_id=${currentUserId}`).then(r => r.json()),
            fetch(`/api/subscription?user_id=${currentUserId}`).then(r => r.json())
        ]);

        updateDashboard(status);
        updateSubscriptionUI(subscription);
    } catch (e) {
        console.error('Failed to load dashboard:', e);
    }
}

async function loadInitialData() {
    await loadDashboardData();
    await loadHistory();
}

function updateDashboard(data) {
    // Update balance
    const equity = data.equity_history?.[data.equity_history.length - 1]?.equity || 5;
    document.getElementById('balanceValue').textContent = equity.toFixed(2) + ' USDT';

    // Update positions
    updatePositionsList(data.positions);

    // Update equity chart
    if (data.equity_history) setEquityData(data.equity_history);

    // Update positions count
    const count = data.positions?.length || 0;
    document.getElementById('positionsCount').textContent = count;
}

function updatePositionsList(positions) {
    const container = document.getElementById('positionsList');
    if (!container) return;

    if (!positions?.length) {
        container.innerHTML = `
            <div class="empty-state" id="emptyPositions">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                    <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline>
                    <polyline points="16 7 22 7 22 13"></polyline>
                </svg>
                <p>Нет открытых позиций</p>
                <span class="hint">Сделки появятся здесь автоматически</span>
            </div>
        `;
        return;
    }

    container.innerHTML = positions.map(p => `
        <div class="position-card ${p.side}" onclick="openPositionDetail('${p.symbol}', '${p.side}', ${p.qty}, ${p.entry}, ${p.stop}, ${p.take_profit})">
            <div class="position-header">
                <span class="position-symbol">${p.symbol}</span>
                <span class="position-side ${p.side}">
                    <span class="side-dot"></span>
                    ${p.side === 'buy' ? 'LONG' : 'SHORT'}
                </span>
            </div>
            <div class="position-details">
                <div class="detail-item">
                    <span class="detail-label">Вход</span>
                    <span class="detail-value">${formatPrice(p.entry)}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Объём</span>
                    <span class="detail-value">${p.qty} конт.</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Стоп</span>
                    <span class="detail-value loss">${formatPrice(p.stop)}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Тейк</span>
                    <span class="detail-value profit">${formatPrice(p.take_profit)}</span>
                </div>
            </div>
            <div class="position-progress">
                <div class="progress-bar ${p.side === 'buy' ? '' : 'loss'}" style="width: ${calculateProgress(p.entry, p.stop, p.take_profit, 0)}%"></div>
            </div>
        </div>
    `).join('');

    // Hide empty state
    const empty = document.getElementById('emptyPositions');
    if (empty) empty.style.display = 'none';
}

function calculateProgress(entry, stop, take, current) {
    if (current === 0) return 50; // Middle for demo
    // Simplified - in real app would calculate based on current price
    return 50;
}

function openPositionDetail(symbol, side, qty, entry, stop, take) {
    const modal = document.getElementById('positionModal');
    const title = document.getElementById('positionModalTitle');
    const body = document.getElementById('positionModalBody');

    title.textContent = `${symbol} ${side === 'buy' ? 'LONG' : 'SHORT'}`;
    body.innerHTML = `
        <div class="position-detail-grid">
            <div class="detail-row">
                <span class="detail-label">Symbol</span>
                <span class="detail-value">${symbol}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Side</span>
                <span class="detail-value">${side === 'buy' ? 'LONG 📈' : 'SHORT 📉'}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Contracts</span>
                <span class="detail-value">${qty}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Entry</span>
                <span class="detail-value">${formatPrice(entry)}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Stop Loss</span>
                <span class="detail-value loss">${formatPrice(stop)}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Take Profit</span>
                <span class="detail-value profit">${formatPrice(take)}</span>
            </div>
            <div class="detail-row full">
                <span class="detail-label">Risk / Reward</span>
                <span class="detail-value">${calculateRR(entry, stop, take)}</span>
            </div>
        </div>
    `;
    document.getElementById('positionModal').classList.add('active');
}

function closePositionModal() {
    document.getElementById('positionModal').classList.remove('active');
}

// ========================================
// History
// ========================================
async function loadHistory() {
    try {
        const data = await fetch(`/api/trades?limit=50&user_id=${currentUserId}`).then(r => r.json());
        renderHistory(data.trades || []);
    } catch (e) {
        console.error('Failed to load history:', e);
    }
}

function renderHistory(trades) {
    const container = document.getElementById('historyList');
    if (!container) return;

    if (!trades?.length) {
        container.innerHTML = `
            <div class="empty-state">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                </svg>
                <p>История пуста</p>
                <span class="hint">Закрытые сделки появятся здесь</span>
            </div>
        `;
        return;
    }

    container.innerHTML = trades.map(t => {
        const pnl = (t.side === 'buy' ? 1 : -1) * (t.tp - t.entry) * t.qty; // Simplified
        const isProfit = pnl > 0;
        return `
            <div class="trade-item">
                <div class="trade-header">
                    <span class="trade-symbol">${t.symbol}</span>
                    <span class="trade-time">${formatTime(t.ts)}</span>
                </div>
                <div class="trade-result">
                    <span class="trade-side ${t.side}">${t.side === 'buy' ? 'LONG' : 'SHORT'}</span>
                    <div class="trade-result-right">
                        <span class="trade-pnl ${isProfit ? 'profit' : 'loss'}">${isProfit ? '+' : ''}${pnl.toFixed(4)} USDT</span>
                        <span class="trade-info">${t.side === 'buy' ? 'LONG' : 'SHORT'} · ${formatTime(t.ts)}</span>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

async function loadMoreHistory() {
    // TODO: Implement pagination
    showToast('Load more history - coming soon', 'info');
}

// ========================================
// Subscription UI
// ========================================
function updateSubscriptionUI(data) {
    const hasSub = data.has_active || currentUserId === 7318737159;
    const btn = document.getElementById('subscribeBtn');
    if (btn) {
        if (hasSub) {
            btn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg><span>Active</span>';
            btn.style.background = 'linear-gradient(135deg, #22c55e, #16a34a)';
            btn.onclick = () => showMySub();
        } else {
            btn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"></rect><line x1="6" y1="8" x2="18" y2="8"></line><line x1="6" y1="12" x2="18" y2="12"></line><line x1="6" y1="16" x2="12" y2="16"></line></svg><span>Subscribe</span>';
            btn.style.background = 'linear-gradient(135deg, #22d3ee, #06b6d4)';
            btn.onclick = openSubscribeModal;
        }
    }
}

function openSubscribeModal() {
    const modal = document.getElementById('subscribeModal');
    const container = document.getElementById('planCards');

    // Import PLANS from payment_cryptobot or define locally
    const plans = {
        day: { name: '1 день', price_usd: 50, days: 1, features: ['Доступ к сигналам', 'Уведомления о сделках', 'История сделок'] },
        week: { name: '1 неделя', price_usd: 100, days: 7, features: ['Всё из 1 дня', 'Приоритетная поддержка', 'Расширенная статистика'] },
        month: { name: '1 месяц', price_usd: 250, days: 30, features: ['Всё из недели', 'Персональные настройки', 'API доступ'] }
    };

    container.innerHTML = Object.entries(plans).map(([key, plan]) => `
        <div class="plan-card ${key === 'week' ? 'recommended' : ''}" onclick="createInvoice('${key}')">
            <div class="plan-header">
                <span class="plan-name">${plan.name}</span>
                <span class="plan-price">$${plan.price_usd}</span>
            </div>
            <p class="plan-desc">Доступ на ${plan.days} ${plan.days === 1 ? 'день' : plan.days < 30 ? 'дня' : 'дней'}</p>
            <div class="plan-features">
                ${plan.features.map(f => `<span class="plan-feature">${f}</span>`).join('')}
            </div>
        </div>
    `).join('');

    document.getElementById('subscribeModal').classList.add('active');
}

function closeSubscribeModal() {
    document.getElementById('subscribeModal').classList.remove('active');
}

async function createInvoice(planKey) {
    const plans = { day: 50, week: 100, month: 250 };
    const amount = plans[planKey];

    try {
        showToast('Creating invoice...', 'info');
        const res = await fetch(`/api/trade/open`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                symbol: 'SUBSCRIPTION',
                side: 'buy',
                qty: amount,
                entry: amount,
                stop: 0,
                take: 0,
                notional: amount
            })
        });
        // Actually should call a subscription endpoint
        // For now redirect to a placeholder
        showToast('Invoice creation - implement API endpoint', 'info');
    } catch (e) {
        showToast('Error creating invoice', 'error');
    }
}

function closeSubscribeModal() {
    document.getElementById('subscribeModal').classList.remove('active');
}

function showMySub() {
    // TODO: Show my subscription details
    showToast('Subscription details - coming soon', 'info');
}

// ========================================
// Tabs
// ========================================
function initTabs() {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
            item.classList.add('active');
            // TODO: Show corresponding section
        });
    });

    // Timeframe buttons
    document.querySelectorAll('.tf-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.tf-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            // TODO: Reload chart with new timeframe
        });
    });
}

// ========================================
// Modals
// ========================================
function initModals() {
    // Close on overlay click
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) overlay.classList.remove('active');
        });
    });

    // ESC to close
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
        }
    });
}

function closeSubscribeModal() {
    document.getElementById('subscribeModal').classList.remove('active');
}

function closePositionModal() {
    document.getElementById('positionModal').classList.remove('active');
}

// ========================================
// Toasts
// ========================================
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    const icons = {
        success: '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>',
        error: '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>',
        info: '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="#22d3ee" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>'
    };
    toast.innerHTML = `
        ${icons[type] || icons.info}
        <div class="toast-content">
            <div class="toast-title">${type === 'success' ? 'Success' : type === 'error' ? 'Error' : 'Info'}</div>
            <div class="toast-message">${message}</div>
        </div>
        <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
    `;
    container.appendChild(toast);

    // Trigger animation
    requestAnimationFrame(() => toast.classList.add('show'));

    // Auto remove
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 5000);
}

// ========================================
// Utilities
// ========================================
function formatPrice(price) {
    if (price >= 1) return price.toFixed(4);
    if (price >= 0.01) return price.toFixed(6);
    return price.toFixed(8);
}

function formatTime(ts) {
    const d = new Date(ts * 1000);
    return d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
}

function formatDate(ts) {
    const d = new Date(ts * 1000);
    return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function calculateRR(entry, stop, take) {
    const risk = Math.abs(entry - stop);
    const reward = Math.abs(take - entry);
    return risk > 0 ? (reward / risk).toFixed(2) : 'N/A';
}