"""Telegram Mini App Backend — FastAPI + WebSocket для real-time дашборда."""
import asyncio
import json
import logging
import os
import sqlite3
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Dict, List, Optional, Set

from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

# Подключаем существующие модули бота
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from subscription_manager import SubscriptionManager, sub_manager
from payment_cryptobot import PLANS

log = logging.getLogger("mini_app")

# ──────────────────────────────────────────────
# WebSocket Manager для real-time обновлений
# ──────────────────────────────────────────────
class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[int, Set[WebSocket]] = {}

    async def connect(self, user_id: int, websocket: WebSocket):
        await websocket.accept()
        if user_id not in self.active_connections:
            self.active_connections[user_id] = set()
        self.active_connections[user_id].add(websocket)
        log.info(f"WS connect: user={user_id}, total={len(self.active_connections[user_id])}")

    def disconnect(self, user_id: int, websocket: WebSocket):
        if user_id in self.active_connections:
            self.active_connections[user_id].discard(websocket)
            if not self.active_connections[user_id]:
                del self.active_connections[user_id]
        log.info(f"WS disconnect: user={user_id}")

    async def send_personal_json(self, user_id: int, data: dict):
        if user_id in self.active_connections:
            dead = set()
            for ws in self.active_connections[user_id]:
                try:
                    await ws.send_json(data)
                except Exception:
                    dead.add(ws)
            for ws in dead:
                self.active_connections[user_id].discard(ws)

    async def broadcast_json(self, data: dict):
        for user_id, connections in self.active_connections.items():
            dead = set()
            for ws in connections:
                try:
                    await ws.send_json(data)
                except Exception:
                    dead.add(ws)
            for ws in dead:
                connections.discard(ws)


manager = ConnectionManager()
sub_manager = SubscriptionManager()

# ──────────────────────────────────────────────
# Models
# ──────────────────────────────────────────────
class TradeOpenRequest(BaseModel):
    symbol: str
    side: str
    qty: float
    entry: float
    stop: float
    take: float
    notional: float

class TradeCloseRequest(BaseModel):
    symbol: str
    side: str
    qty: float
    entry: float
    exit_price: float
    pct: float
    pnl: float
    reason: str

class GrantSubRequest(BaseModel):
    user_id: int
    plan: str  # day|week|month

class BotCommandRequest(BaseModel):
    command: str  # start|stop|panic|status


# ──────────────────────────────────────────────
# Database helpers
# ──────────────────────────────────────────────
DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "trades.db")
SUB_DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "subscriptions.db")


def get_trades(limit: int = 100, user_id: int = None) -> List[dict]:
    """Получить историю сделок из trades.db"""
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        if user_id:
            # Фильтрация по пользователю — если есть связь user_id в trades
            cur = conn.execute("""
                SELECT * FROM trades ORDER BY ts DESC LIMIT ?
            """, (limit,))
        else:
            cur = conn.execute("SELECT * FROM trades ORDER BY ts DESC LIMIT ?", (limit,))
        return [dict(row) for row in cur.fetchall()]


def get_open_positions() -> List[dict]:
    """Получить открытые позиции — читает из positions_state.json"""
    try:
        state_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), "positions_state.json")
        if os.path.exists(state_file):
            with open(state_file, "r") as f:
                data = json.load(f)
            positions = []
            for key, pos in data.items():
                positions.append({
                    "symbol": pos.get("symbol"),
                    "side": pos.get("side"),
                    "qty": pos.get("qty"),
                    "entry": pos.get("entry"),
                    "stop": pos.get("stop"),
                    "take_profit": pos.get("take_profit"),
                    "peak_pct": pos.get("peak_pct", 0),
                })
            return positions
    except Exception as e:
        log.error(f"Error reading positions: {e}")
    return []


def get_equity_history(limit: int = 200) -> List[dict]:
    """История эквити — для графика. Читает из trades.db и считает кумулятивный PnL."""
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        cur = conn.execute("SELECT ts, symbol, side, qty, entry, sl, tp, reason FROM trades ORDER BY ts ASC")
        rows = cur.fetchall()

    # Грубая симуляция equity для демо
    equity = 5.0  # стартовый баланс
    history = []
    for row in rows[-limit:]:
        # Это заглушка — в реальности нужно считать PnL по закрытым сделкам
        history.append({
            "ts": row["ts"],
            "equity": equity,
            "symbol": row["symbol"],
        })
    return history


# ──────────────────────────────────────────────
# FastAPI App
# ──────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    log.info("🚀 Mini App started")
    yield
    # Shutdown
    log.info("🛑 Mini App stopped")


app = FastAPI(title="Trading Bot Mini App", lifespan=lifespan)

# Static files & templates
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))

# ──────────────────────────────────────────────
# WebSocket
# ──────────────────────────────────────────────
@app.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: int):
    # Простая проверка подписки
    if not sub_manager.has_active_subscription(user_id) and user_id != 7318737159:
        await websocket.close(code=4003, reason="No active subscription")
        return

    await manager.connect(user_id, websocket)
    try:
        # Отправляем начальное состояние
        await websocket.send_json({
            "type": "init",
            "positions": get_open_positions(),
            "equity_history": get_equity_history(),
            "subscription": sub_manager.get_subscription_info(user_id),
        })
        while True:
            # Держим соединение, слушаем пинги/команды от клиента
            data = await websocket.receive_json()
            # Можно обработать команды от клиента (ping, запрос обновления и т.д.)
    except WebSocketDisconnect:
        manager.disconnect(user_id, websocket)
    except Exception as e:
        log.error(f"WS error for user {user_id}: {e}")
        manager.disconnect(user_id, websocket)


# ──────────────────────────────────────────────
# API Routes
# ──────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def index(request: Request, user_id: int = 7318737159):
    """Главная страница Mini App"""
    # В реальности user_id берём из Telegram WebApp initData
    has_sub = sub_manager.has_active_subscription(user_id) or user_id == 7318737159
    sub_info = sub_manager.get_subscription_info(user_id)
    return templates.TemplateResponse("index.html", {
        "request": request,
        "user_id": user_id,
        "has_subscription": has_sub,
        "sub_info": sub_info,
        "plans": PLANS,
        "is_admin": user_id == 7318737159,
    })


@app.get("/api/status")
async def api_status(user_id: int = 7318737159):
    """Текущий статус бота"""
    positions = get_open_positions()
    equity_hist = get_equity_history()
    return {
        "positions": positions,
        "equity_history": equity_hist,
        "subscription": sub_manager.get_subscription_info(user_id),
        "timestamp": int(time.time()),
    }


@app.get("/api/trades")
async def api_trades(limit: int = 50, user_id: int = 7318737159):
    """История сделок"""
    trades = get_trades(limit)
    return {"trades": trades}


@app.get("/api/subscription")
async def api_subscription(user_id: int = 7318737159):
    """Информация о подписке"""
    return {
        "info": sub_manager.get_subscription_info(user_id),
        "plans": PLANS,
        "has_active": sub_manager.has_active_subscription(user_id) or user_id == 7318737159,
    }


@app.post("/api/trade/open")
async def trade_open(req: TradeOpenRequest, user_id: int = 7318737159):
    """Уведомление об открытии сделки (от бота)"""
    # Рассылаем всем подписчикам через WS
    await manager.broadcast_json({
        "type": "trade_open",
        "data": req.dict(),
        "timestamp": int(time.time()),
    })
    return {"ok": True}


@app.post("/api/trade/close")
async def trade_close(req: TradeCloseRequest, user_id: int = 7318737159):
    """Уведомление о закрытии сделки (от бота)"""
    await manager.broadcast_json({
        "type": "trade_close",
        "data": req.dict(),
        "timestamp": int(time.time()),
    })
    return {"ok": True}


@app.post("/api/admin/grant")
async def admin_grant(req: GrantSubRequest, user_id: int = 7318737159):
    """Выдать подписку (только админ)"""
    if user_id != 7318737159:
        raise HTTPException(403, "Admin only")
    plan = PLANS.get(req.plan)
    if not plan:
        raise HTTPException(400, "Invalid plan")
    sub_manager.create_or_update_user(req.user_id, "")
    sub_manager.activate_subscription(req.user_id, req.plan, plan["days"], 0, plan["price_usd"], "ADMIN")
    return {"ok": True, "message": f"Granted {plan['name']} to {req.user_id}"}


@app.post("/api/admin/command")
async def admin_command(req: BotCommandRequest, user_id: int = 7318737159):
    """Админ-команды (start/stop/panic)"""
    if user_id != 7318737159:
        raise HTTPException(403, "Admin only")
    # Здесь можно вызвать engine.pause/resume/emergency_stop через глобальный объект
    return {"ok": True, "command": req.command}


@app.post("/webhook/cryptobot")
async def cryptobot_webhook(request: Request):
    """Вебхук от CryptoBot"""
    body = await request.body()
    signature = request.headers.get("Crypto-Pay-API-Signature", "")
    # TODO: verify signature
    data = json.loads(body)
    # TODO: process invoice_paid
    return {"ok": True}


# ──────────────────────────────────────────────
# Frontend
# ──────────────────────────────────────────────
@app.get("/app", response_class=HTMLResponse)
async def mini_app(request: Request, user_id: int = 7318737159):
    """Точка входа Mini App (открывается в Telegram)"""
    has_sub = sub_manager.has_active_subscription(user_id) or user_id == 7318737159
    return templates.TemplateResponse("index.html", {
        "request": request,
        "user_id": user_id,
        "has_subscription": has_sub or user_id == 7318737159,
        "is_admin": user_id == 7318737159,
    })


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)